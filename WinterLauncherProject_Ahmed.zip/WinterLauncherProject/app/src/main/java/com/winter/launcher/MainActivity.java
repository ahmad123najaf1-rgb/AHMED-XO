package com.winter.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    WinterView winterView;
    @Override public void onCreate(Bundle b){super.onCreate(b); winterView=new WinterView(this);setContentView(winterView);}
    @Override protected void onResume(){super.onResume();if(winterView!=null)winterView.start();}
    @Override protected void onPause(){super.onPause();if(winterView!=null)winterView.stop();}
    class AppItem {String label,pkg; Drawable icon; AppItem(String l,String p,Drawable i){label=l;pkg=p;icon=i;}}
    class WinterView extends View {
        Paint p=new Paint(3); Bitmap bg; ArrayList<AppItem> apps=new ArrayList<>(); ArrayList<Snow> flakes=new ArrayList<>();
        boolean snowOn=true,showDrawer=false; int accent=Color.rgb(255,205,126); float density=1;
        long last=0; Handler handler=new Handler(Looper.getMainLooper()); Runnable ticker=()->invalidate();
        float w,h; RectF[] appRects=new RectF[20]; RectF settingRect,drawerRect,playerRect,creditRect;
        String[] appNames={"Phone","Messages","Chrome","Camera","YouTube","Play Store","Settings","WhatsApp"};
        public WinterView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            bg=BitmapFactory.decodeResource(getResources(),R.drawable.winter_bg);
            loadApps(); for(int i=0;i<130;i++)flakes.add(new Snow());
        }
        void loadApps(){
            PackageManager pm=getPackageManager();
            Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> rs=pm.queryIntentActivities(intent,0);
            for(ResolveInfo r:rs){String pkg=r.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;
                apps.add(new AppItem(r.loadLabel(pm).toString(),pkg,r.loadIcon(pm)));}
            Collections.sort(apps,(a,b)->a.label.compareToIgnoreCase(b.label));
        }
        void start(){handler.removeCallbacks(ticker);handler.post(ticker);}
        void stop(){handler.removeCallbacks(ticker);}
        class Snow {float x=(float)Math.random(),y=(float)Math.random(),r=1+(float)Math.random()*3,v=.15f+(float)Math.random()*.6f,dr=((float)Math.random()-.5f)*.25f;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);w=getWidth();h=getHeight();
            if(bg!=null){Rect src=new Rect(0,0,bg.getWidth(),bg.getHeight());float scale=Math.max(w/bg.getWidth(),h/bg.getHeight());
                float sw=w/scale,sh=h/scale;src.set((int)((bg.getWidth()-sw)/2),(int)((bg.getHeight()-sh)/2),(int)((bg.getWidth()+sw)/2),(int)((bg.getHeight()+sh)/2));
                c.drawBitmap(bg,src,new Rect(0,0,(int)w,(int)h),p);}
            p.setColor(0x22051327);c.drawRect(0,0,w,h,p);
            drawSnow(c);
            drawStatus(c);
            drawWidgets(c);
            drawApps(c);
            if(showDrawer)drawDrawer(c);
        }
        void round(Canvas c,RectF r,float rad,int color,int stroke){
            p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(r,rad,rad,p);
            if(stroke!=0){p.setColor(stroke);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.2f);c.drawRoundRect(r,rad,rad,p);p.setStyle(Paint.Style.FILL);}
        }
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align){
            p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif-light",Typeface.NORMAL));p.setTextAlign(align);c.drawText(s,x,y,p);
        }
        void drawStatus(Canvas c){text(c,new SimpleDateFormat("h:mm",Locale.getDefault()).format(new Date()),w*.06f,h*.035f,13,Color.WHITE,true,Paint.Align.LEFT);
            text(c,"◈  ▰  87%",w*.94f,h*.035f,12,Color.WHITE,true,Paint.Align.RIGHT);}
        void drawWidgets(Canvas c){
            float top=h*.075f; RectF clock=new RectF(w*.045f,top,w*.57f,top+h*.15f);
            RectF weather=new RectF(w*.60f,top,w*.955f,top+h*.15f);
            round(c,clock,24,0x77304766,0x44FFFFFF);round(c,weather,24,0x77304766,0x44FFFFFF);
            String time=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());
            text(c,time,clock.centerX(),clock.top+h*.07f,h*.052f,accent,false,Paint.Align.CENTER);
            text(c,new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()),clock.centerX(),clock.top+h*.112f,13,Color.WHITE,false,Paint.Align.CENTER);
            text(c,"❄",weather.centerX(),weather.top+h*.055f,29,Color.WHITE,false,Paint.Align.CENTER);
            text(c,"—°",weather.centerX(),weather.top+h*.09f,26,Color.WHITE,false,Paint.Align.CENTER);
            text(c,"طقس شتوي",weather.centerX(),weather.top+h*.12f,12,Color.WHITE,false,Paint.Align.CENTER);
            playerRect=new RectF(w*.04f,top+h*.165f,w*.96f,top+h*.25f);
            round(c,playerRect,20,0x77304766,0x44FFFFFF);
            text(c,"🏔",playerRect.left+34,playerRect.centerY()+10,30,Color.WHITE,false,Paint.Align.CENTER);
            text(c,"Winter Vibes",playerRect.left+70,playerRect.centerY()-3,15,Color.WHITE,true,Paint.Align.LEFT);
            text(c,"Chill LoFi  ·  ♫  ⏮   ▶   ⏭",playerRect.left+70,playerRect.centerY()+19,12,Color.WHITE,false,Paint.Align.LEFT);
            settingRect=new RectF(w*.82f,h*.29f,w*.95f,h*.33f);
            text(c,"⚙",settingRect.centerX(),settingRect.centerY()+12,26,Color.WHITE,false,Paint.Align.CENTER);
        }
        void drawApps(Canvas c){
            int count=Math.min(apps.size(),10);float startY=h*.64f;float cols=5;float cellW=w/cols;float cellH=h*.095f;
            appRects=new RectF[count];
            for(int i=0;i<count;i++){int row=i/5,col=i%5;float x=col*cellW+cellW/2,y=startY+row*cellH;
                RectF box=new RectF(x-27,y-27,x+27,y+27);appRects[i]=box;round(c,box,15,0x77304766,0x44FFFFFF);
                Drawable d=apps.get(i).icon;d.setBounds((int)(x-18),(int)(y-18),(int)(x+18),(int)(y+18));d.draw(c);
                String label=apps.get(i).label;if(label.length()>10)label=label.substring(0,9)+"…";
                text(c,label,x,y+43,10,Color.WHITE,false,Paint.Align.CENTER);
            }
            text(c,"●   ○   ○",w/2,h*.85f,13,Color.WHITE,false,Paint.Align.CENTER);\n            creditRect=new RectF(w*.12f,h*.93f,w*.88f,h*.965f);\n            text(c,"© AHMED ALI AL-ISSAWI",w/2,h*.952f,11,0xDDEAF7,false,Paint.Align.CENTER);
            // launcher drawer button
            drawerRect=new RectF(w*.39f,h*.87f,w*.61f,h*.925f);
            round(c,drawerRect,22,0x66485D7A,0x55FFFFFF);
            text(c,"التطبيقات  ▦",drawerRect.centerX(),drawerRect.centerY()+5,14,Color.WHITE,true,Paint.Align.CENTER);
            p.setColor(Color.WHITE);p.setStrokeWidth(4);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(w*.36f,h*.975f,w*.64f,h*.975f,p);
        }
        void drawDrawer(Canvas c){
            p.setColor(0xAA08162B);c.drawRect(0,0,w,h,p);
            RectF panel=new RectF(12,35,w-12,h-35);round(c,panel,25,0xEE18314F,0x55FFFFFF);
            text(c,"كل التطبيقات",w/2,70,22,Color.WHITE,true,Paint.Align.CENTER);
            int cols=4;float cw=(w-30)/cols,top=100;for(int i=0;i<apps.size();i++){int row=i/cols,col=i%cols;if(top+row*95>h-80)break;
                float x=15+col*cw+cw/2,y=top+row*95;Drawable d=apps.get(i).icon;d.setBounds((int)(x-23),(int)(y-23),(int)(x+23),(int)(y+23));d.draw(c);
                String l=apps.get(i).label;if(l.length()>12)l=l.substring(0,11)+"…";text(c,l,x,y+42,10,Color.WHITE,false,Paint.Align.CENTER);}
            text(c,"انقر على التطبيق لفتحه · اضغط خارج اللوحة للعودة",w/2,h-58,12,Color.WHITE,false,Paint.Align.CENTER);
        }
        void drawSnow(Canvas c){if(!snowOn)return;p.setColor(Color.WHITE);for(Snow f:flakes){c.drawCircle(f.x*w,f.y*h,f.r,p);f.y+=f.v/h;f.x+=f.dr/w;if(f.y>1){f.y=0;f.x=(float)Math.random();}if(f.x<0)f.x=1;if(f.x>1)f.x=0;}}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();
            if(showDrawer){if(y<85||y>h-70){showDrawer=false;invalidate();return true;}
                int cols=4;float cw=(w-30)/cols;int col=(int)((x-15)/cw),row=(int)((y-100)/95);int idx=row*cols+col;if(idx>=0&&idx<apps.size()){launch(apps.get(idx));}return true;}
            if(settingRect!=null&&settingRect.contains(x,y)){showSettings();return true;}\n            if(creditRect!=null&&creditRect.contains(x,y)){showSocials();return true;}
            if(drawerRect!=null&&drawerRect.contains(x,y)){showDrawer=true;invalidate();return true;}
            if(playerRect!=null&&playerRect.contains(x,y)){Toast.makeText(MainActivity.this,"مشغل الموسيقى يحتاج ربطًا بخدمة صوتية",Toast.LENGTH_SHORT).show();return true;}
            if(appRects!=null)for(int i=0;i<appRects.length;i++)if(appRects[i]!=null&&appRects[i].contains(x,y)){launch(apps.get(i));return true;}
            return true;
        }
        void launch(AppItem a){try{Intent it=getPackageManager().getLaunchIntentForPackage(a.pkg);if(it!=null){it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(it);}}catch(Exception ex){Toast.makeText(MainActivity.this,"تعذر فتح التطبيق",Toast.LENGTH_SHORT).show();}}
        void showSocials(){
            final String[] labels={"🎵 TikTok | تيك توك","🎥 YouTube | يوتيوب","📸 Instagram | إنستغرام الشخصي","📘 Facebook | فيسبوك","🎬 Instagram | إنستغرام الأدِتات والشروحات","📢 Telegram Channel | قناة التليجرام","📝 My Blog | المدونة الرسمية"};
            final String[] urls={"https://tiktok.com/@ahmed.ali.alissawi","https://youtube.com/@ahmedalialissawi","https://instagram.com/not_ast5","https://facebook.com/profile.php?id=100052449435860","https://instagram.com/ahmed.ali.alissaw","https://telegram.me/ahmedalialissawi","https://ahmedalialissawi1.blogspot.com"};
            new AlertDialog.Builder(MainActivity.this).setTitle("AHMED ALI AL-ISSAWI\\nحساباتي الرسمية").setItems(labels,(dialog,which)->{
                try{Intent view=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(urls[which]));startActivity(view);}
                catch(Exception e){Toast.makeText(MainActivity.this,"تعذر فتح الرابط",Toast.LENGTH_SHORT).show();}
            }).setPositiveButton("إغلاق",null).show();
        }
        void showSettings(){String[] opts={"تبديل تساقط الثلج","كثافة الثلج: متوسط","لون الساعة: ذهبي","إعدادات اللانشر"};new AlertDialog.Builder(MainActivity.this).setTitle("Winter Settings").setItems(opts,(d,which)->{
            if(which==0){snowOn=!snowOn;invalidate();}
            if(which==1){for(Snow f:flakes)f.r=1+(float)Math.random()*4;invalidate();}
            if(which==2){accent=accent==Color.rgb(255,205,126)?Color.rgb(196,230,255):Color.rgb(255,205,126);invalidate();}
            if(which==3){Intent intent=new Intent(Settings.ACTION_HOME_SETTINGS);try{startActivity(intent);}catch(Exception e){Toast.makeText(MainActivity.this,"اختر Winter كتطبيق الشاشة الرئيسية من إعدادات النظام",Toast.LENGTH_LONG).show();}}
        }).show();}
    }
}
